import { useState, useEffect } from 'react';
import { Landing } from './components/Landing';
import { DisasterMap } from './components/DisasterMap';
import { ReportSheet } from './components/ReportSheet';
import { AgentDashboard } from './components/AgentDashboard';
import { EvacuationMode } from './components/EvacuationMode';
import { Settings } from './components/Settings';
import { AnimatedBackground } from './components/AnimatedBackground';
import { SignIn } from './components/SignIn';
import { SignUp } from './components/SignUp';
import { useRealtimeData } from './hooks/useRealtimeData';
import { AppProvider, useAppContext } from './context/AppContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Toaster } from './components/ui/sonner';

// Suppress Three.js multiple instances warning (known issue with @react-three/fiber and @react-three/drei)
const originalWarn = console.warn;
const originalError = console.error;

console.warn = (...args) => {
  const msg = typeof args[0] === 'string' ? args[0] : String(args[0]);
  if (msg && (msg.includes('Three.js') || msg.includes('THREE'))) {
    return;
  }
  originalWarn.apply(console, args);
};

console.error = (...args) => {
  const msg = typeof args[0] === 'string' ? args[0] : String(args[0]);
  if (msg && (msg.includes('Multiple instances of Three.js') || msg.includes('THREE'))) {
    return;
  }
  originalError.apply(console, args);
};

/**
 * ResQMap - Real-time Disaster Relief Mapping Platform
 * 
 * Architecture:
 * - Frontend: React 18 + TypeScript + Tailwind + Motion
 * - 3D: React-Three-Fiber + Drei
 * - Maps: Mapbox GL JS + deck.gl
 * - State: Context API + Mock Realtime (Supabase-ready)
 * 
 * Color Palette:
 * - Primary (Safe): #568203
 * - Dark Navy: #0B2B5A
 * - Hazard Red: #E94B35
 * - Caution Amber: #FF9A00
 * - Neutral: #F7F9FB
 * - Pink Accents: #FF006E, #FD49A0, #C70055
 */

type Screen = 'landing' | 'map' | 'evacuation' | 'settings';
type AuthScreen = 'signin' | 'signup' | null;

function AppContent() {
  const { theme } = useAppContext();
  const { isAuthenticated } = useAuth();
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [authScreen, setAuthScreen] = useState<AuthScreen>(null);
  const [showReportSheet, setShowReportSheet] = useState(false);
  const [showAgentDashboard, setShowAgentDashboard] = useState(false);
  const [evacuationActive, setEvacuationActive] = useState(false);

  // Apply theme to document root
  useEffect(() => {
    document.documentElement.className = theme;
  }, [theme]);

  // Show auth if not authenticated
  useEffect(() => {
    if (!isAuthenticated && authScreen === null) {
      setAuthScreen('signin');
    }
  }, [isAuthenticated, authScreen]);

  // Auto-transition from landing to map after 3 seconds
  useEffect(() => {
    if (currentScreen === 'landing' && isAuthenticated) {
      const timer = setTimeout(() => {
        setCurrentScreen('map');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [currentScreen, isAuthenticated]);

  // Check for high-severity alerts (mock logic)
  const { hazards } = useRealtimeData();
  useEffect(() => {
    const criticalHazards = hazards.filter(h => h.severity === 'critical');
    if (criticalHazards.length > 0 && !evacuationActive) {
      // Auto-trigger evacuation mode for demo
      // In production, this would be based on complex alert rules
    }
  }, [hazards, evacuationActive]);

  // Handle successful authentication
  const handleAuthSuccess = () => {
    setAuthScreen(null);
    setCurrentScreen('landing');
  };

  return (
    <div className={`w-full h-screen overflow-hidden ${theme}`}>
      <AnimatedBackground />
      <Toaster position="top-right" theme={theme} />
      
      {/* Authentication Screens */}
      {authScreen === 'signin' && (
        <SignIn 
          onSuccess={handleAuthSuccess}
          onSwitchToSignUp={() => setAuthScreen('signup')}
        />
      )}
      
      {authScreen === 'signup' && (
        <SignUp 
          onSuccess={handleAuthSuccess}
          onSwitchToSignIn={() => setAuthScreen('signin')}
        />
      )}

      {/* Main App (only if authenticated) */}
      {isAuthenticated && authScreen === null && (
        <>
          {/* Landing Screen */}
          {currentScreen === 'landing' && (
            <Landing onEnter={() => setCurrentScreen('map')} />
          )}

          {/* Main Map View */}
          {currentScreen === 'map' && !evacuationActive && (
            <DisasterMap
              onCreateReport={() => setShowReportSheet(true)}
              onOpenAgents={() => setShowAgentDashboard(true)}
              onOpenSettings={() => setCurrentScreen('settings')}
              onEvacuate={() => setEvacuationActive(true)}
            />
          )}

          {/* Evacuation Mode */}
          {evacuationActive && (
            <EvacuationMode
              onClose={() => setEvacuationActive(false)}
              onBackToMap={() => {
                setEvacuationActive(false);
                setCurrentScreen('map');
              }}
            />
          )}

          {/* Settings Screen */}
          {currentScreen === 'settings' && (
            <Settings onBack={() => setCurrentScreen('map')} />
          )}

          {/* Report Creation Sheet (Modal) */}
          {showReportSheet && (
            <ReportSheet onClose={() => setShowReportSheet(false)} />
          )}

          {/* Agent Dashboard Overlay */}
          {showAgentDashboard && (
            <AgentDashboard onClose={() => setShowAgentDashboard(false)} />
          )}
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
}