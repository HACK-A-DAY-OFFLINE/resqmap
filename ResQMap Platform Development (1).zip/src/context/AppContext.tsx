import { createContext, useContext, useState, ReactNode } from 'react';

/**
 * Global Application State
 * 
 * Manages:
 * - User session
 * - Offline mode
 * - Theme preferences
 * - Real-time connection status
 */

interface User {
  id: string;
  name: string;
  role: 'responder' | 'coordinator' | 'civilian';
  location?: [number, number]; // [lng, lat]
}

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  offlineMode: boolean;
  toggleOfflineMode: () => void;
  reducedMotion: boolean;
  toggleReducedMotion: () => void;
  connectionStatus: 'connected' | 'connecting' | 'disconnected';
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  
  const [offlineMode, setOfflineMode] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [connectionStatus] = useState<'connected' | 'connecting' | 'disconnected'>('connected');
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  const toggleOfflineMode = () => setOfflineMode(prev => !prev);
  const toggleReducedMotion = () => setReducedMotion(prev => !prev);
  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        offlineMode,
        toggleOfflineMode,
        reducedMotion,
        toggleReducedMotion,
        connectionStatus,
        theme,
        toggleTheme,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
}