import { createContext, useContext, useState, ReactNode } from 'react';

/**
 * Authentication Context
 * 
 * Manages user authentication state, credentials, and session persistence
 * 
 * Features:
 * - Sign Up with validation
 * - Sign In with credential check
 * - Session persistence (mock localStorage)
 * - Validation states
 */

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: 'responder' | 'coordinator' | 'civilian';
  createdAt: string;
}

export interface Credentials {
  email: string;
  password: string;
  name?: string;
}

export type AuthState = 'idle' | 'validating' | 'success' | 'failure' | 'network-error';

interface AuthContextType {
  user: AuthUser | null;
  authState: AuthState;
  isAuthenticated: boolean;
  signUp: (credentials: Credentials) => Promise<{ success: boolean; error?: string }>;
  signIn: (credentials: Credentials) => Promise<{ success: boolean; error?: string }>;
  signOut: () => void;
  validateEmail: (email: string) => boolean;
  validatePassword: (password: string) => { valid: boolean; strength: 'weak' | 'medium' | 'strong' };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock credential storage
const STORAGE_KEY = 'resqmap_users';

function getStoredUsers(): Array<{ email: string; password: string; user: AuthUser }> {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

function storeUser(email: string, password: string, user: AuthUser) {
  const users = getStoredUsers();
  users.push({ email, password, user });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
}

function findUser(email: string, password: string): AuthUser | null {
  const users = getStoredUsers();
  const found = users.find(u => u.email === email && u.password === password);
  return found ? found.user : null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [authState, setAuthState] = useState<AuthState>('idle');

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password: string): { valid: boolean; strength: 'weak' | 'medium' | 'strong' } => {
    if (password.length < 6) {
      return { valid: false, strength: 'weak' };
    }
    
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    const score = [hasUpperCase, hasLowerCase, hasNumbers, hasSpecialChar].filter(Boolean).length;
    
    if (score < 2 || password.length < 8) {
      return { valid: true, strength: 'weak' };
    } else if (score < 3 || password.length < 10) {
      return { valid: true, strength: 'medium' };
    } else {
      return { valid: true, strength: 'strong' };
    }
  };

  const signUp = async (credentials: Credentials): Promise<{ success: boolean; error?: string }> => {
    setAuthState('validating');
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Validate email
    if (!validateEmail(credentials.email)) {
      setAuthState('failure');
      return { success: false, error: 'Invalid email format' };
    }
    
    // Validate password
    const passwordCheck = validatePassword(credentials.password);
    if (!passwordCheck.valid) {
      setAuthState('failure');
      return { success: false, error: 'Password must be at least 6 characters' };
    }
    
    // Check if name provided
    if (!credentials.name || credentials.name.trim().length < 2) {
      setAuthState('failure');
      return { success: false, error: 'Name must be at least 2 characters' };
    }
    
    // Check if user already exists
    const users = getStoredUsers();
    if (users.some(u => u.email === credentials.email)) {
      setAuthState('failure');
      return { success: false, error: 'Email already registered' };
    }
    
    // Create new user
    const newUser: AuthUser = {
      id: `user-${Date.now()}`,
      email: credentials.email,
      name: credentials.name,
      role: 'civilian', // Default role
      createdAt: new Date().toISOString()
    };
    
    storeUser(credentials.email, credentials.password, newUser);
    setUser(newUser);
    setAuthState('success');
    
    return { success: true };
  };

  const signIn = async (credentials: Credentials): Promise<{ success: boolean; error?: string }> => {
    setAuthState('validating');
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Validate email
    if (!validateEmail(credentials.email)) {
      setAuthState('failure');
      return { success: false, error: 'Invalid email format' };
    }
    
    // Find user
    const foundUser = findUser(credentials.email, credentials.password);
    
    if (!foundUser) {
      setAuthState('failure');
      return { success: false, error: 'Invalid email or password' };
    }
    
    setUser(foundUser);
    setAuthState('success');
    
    return { success: true };
  };

  const signOut = () => {
    setUser(null);
    setAuthState('idle');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        authState,
        isAuthenticated: user !== null,
        signUp,
        signIn,
        signOut,
        validateEmail,
        validatePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
