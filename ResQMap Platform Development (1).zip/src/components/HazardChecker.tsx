import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Flame, Droplet, Construction, Building2, Activity, X, MapPin, Clock } from 'lucide-react';
import { useRealtimeData } from '../hooks/useRealtimeData';
import { useState } from 'react';
import { useAppContext } from '../context/AppContext';

/**
 * Live Hazard Checker Component
 * 
 * Features:
 * - Real-time hazard list
 * - Severity-based filtering
 * - Interactive hazard details
 * - Location information
 */

const hazardIcons = {
  fire: Flame,
  flood: Droplet,
  roadblock: Construction,
  collapse: Building2,
  medical: Activity
};

const hazardColors = {
  fire: '#E94B35',
  flood: '#3B82F6',
  roadblock: '#FF9A00',
  collapse: '#EF4444',
  medical: '#10B981'
};

const severityColors = {
  critical: '#E94B35',
  high: '#FF9A00',
  moderate: '#3B82F6',
  low: '#568203'
};

interface HazardCheckerProps {
  onClose: () => void;
  onHazardClick?: (hazardId: string, location: [number, number]) => void;
}

export function HazardChecker({ onClose, onHazardClick }: HazardCheckerProps) {
  const { hazards } = useRealtimeData();
  const { theme } = useAppContext();
  const [filter, setFilter] = useState<'all' | 'critical' | 'high' | 'moderate' | 'low'>('all');

  const filteredHazards = filter === 'all' 
    ? hazards 
    : hazards.filter(h => h.severity === filter);

  const getTimeAgo = (timestamp: number) => {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ago`;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        transition={{ type: 'spring', damping: 25 }}
        className={`w-full max-w-2xl max-h-[80vh] rounded-xl shadow-2xl overflow-hidden ${
          theme === 'dark' ? 'bg-black/90 border border-[#FF006E]/30' : 'bg-white border border-gray-200'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`p-6 border-b ${theme === 'dark' ? 'border-white/10 bg-[#FF006E]/10' : 'border-gray-200 bg-[#FFE5F1]'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-full ${theme === 'dark' ? 'bg-[#FF006E]/20' : 'bg-[#FF006E]/10'}`}>
                <AlertTriangle className={`w-6 h-6 ${theme === 'dark' ? 'text-[#FF006E]' : 'text-[#C70055]'}`} />
              </div>
              <div>
                <h2 className={theme === 'dark' ? 'text-white' : 'text-gray-900'}>
                  Live Hazard Monitor
                </h2>
                <p className={`text-sm ${theme === 'dark' ? 'text-white/60' : 'text-gray-600'}`}>
                  {filteredHazards.length} active {filter !== 'all' ? filter : ''} hazard{filteredHazards.length !== 1 ? 's' : ''}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className={`p-2 rounded-lg transition-colors ${
                theme === 'dark' 
                  ? 'hover:bg-white/10 text-white/60 hover:text-white' 
                  : 'hover:bg-gray-100 text-gray-600 hover:text-gray-900'
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Filter buttons */}
          <div className="flex gap-2 mt-4">
            {(['all', 'critical', 'high', 'moderate', 'low'] as const).map((severity) => (
              <button
                key={severity}
                onClick={() => setFilter(severity)}
                className={`px-3 py-1 rounded-full text-xs transition-all ${
                  filter === severity
                    ? theme === 'dark'
                      ? 'bg-[#FF006E] text-white'
                      : 'bg-[#FF006E] text-white'
                    : theme === 'dark'
                      ? 'bg-white/10 text-white/60 hover:bg-white/20'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {severity === 'all' ? 'All' : severity.charAt(0).toUpperCase() + severity.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Hazard list */}
        <div className="overflow-y-auto max-h-[calc(80vh-200px)]">
          <AnimatePresence mode="popLayout">
            {filteredHazards.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className={`p-8 text-center ${theme === 'dark' ? 'text-white/60' : 'text-gray-600'}`}
              >
                <AlertTriangle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No {filter !== 'all' ? filter : ''} hazards detected</p>
              </motion.div>
            ) : (
              filteredHazards.map((hazard, index) => {
                const Icon = hazardIcons[hazard.type as keyof typeof hazardIcons] || AlertTriangle;
                const color = hazardColors[hazard.type as keyof typeof hazardColors] || '#FF9A00';
                const severityColor = severityColors[hazard.severity];

                return (
                  <motion.div
                    key={hazard.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    className={`p-4 border-b cursor-pointer transition-colors ${
                      theme === 'dark' 
                        ? 'border-white/10 hover:bg-white/5' 
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                    onClick={() => onHazardClick?.(hazard.id, hazard.location)}
                  >
                    <div className="flex items-start gap-4">
                      {/* Icon */}
                      <div 
                        className="p-3 rounded-lg flex-shrink-0"
                        style={{ backgroundColor: `${color}20` }}
                      >
                        <Icon className="w-5 h-5" style={{ color }} />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h3 className={`truncate ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                            {hazard.title}
                          </h3>
                          <span
                            className="px-2 py-1 rounded text-xs flex-shrink-0"
                            style={{ 
                              backgroundColor: `${severityColor}20`,
                              color: severityColor 
                            }}
                          >
                            {hazard.severity.toUpperCase()}
                          </span>
                        </div>
                        
                        <p className={`text-sm mb-2 line-clamp-2 ${theme === 'dark' ? 'text-white/60' : 'text-gray-600'}`}>
                          {hazard.description}
                        </p>

                        <div className="flex items-center gap-4 text-xs">
                          <div className={`flex items-center gap-1 ${theme === 'dark' ? 'text-white/40' : 'text-gray-500'}`}>
                            <MapPin className="w-3 h-3" />
                            <span>
                              {hazard.location[1].toFixed(4)}, {hazard.location[0].toFixed(4)}
                            </span>
                          </div>
                          <div className={`flex items-center gap-1 ${theme === 'dark' ? 'text-white/40' : 'text-gray-500'}`}>
                            <Clock className="w-3 h-3" />
                            <span>{getTimeAgo(hazard.timestamp)}</span>
                          </div>
                        </div>

                        {/* Pulsing indicator for critical/high */}
                        {(hazard.severity === 'critical' || hazard.severity === 'high') && (
                          <motion.div
                            animate={{
                              opacity: [0.5, 1, 0.5],
                            }}
                            transition={{
                              duration: 2,
                              repeat: Infinity,
                              ease: 'easeInOut',
                            }}
                            className="mt-2 flex items-center gap-1 text-xs"
                            style={{ color: severityColor }}
                          >
                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: severityColor }} />
                            <span>Active alert</span>
                          </motion.div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className={`p-4 border-t ${theme === 'dark' ? 'border-white/10 bg-black/50' : 'border-gray-200 bg-gray-50'}`}>
          <div className="flex items-center justify-between text-xs">
            <span className={theme === 'dark' ? 'text-white/40' : 'text-gray-500'}>
              Last updated: Just now
            </span>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              className={`w-4 h-4 border-2 border-transparent rounded-full ${
                theme === 'dark' ? 'border-t-[#FF006E]' : 'border-t-[#C70055]'
              }`}
            />
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
