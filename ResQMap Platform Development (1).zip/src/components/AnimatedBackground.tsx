import { motion } from 'motion/react';
import { useAppContext } from '../context/AppContext';

/**
 * Animated Background Component
 * 
 * Features:
 * - Gradient background with animated orbs
 * - Black and pinkish color palette
 * - Theme-aware (dark/light mode)
 * - Smooth transitions
 */

export function AnimatedBackground() {
  const { theme } = useAppContext();

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
      {/* Base gradient */}
      <div 
        className={`absolute inset-0 transition-all duration-1000 ${
          theme === 'dark' 
            ? 'bg-gradient-to-br from-black via-[#1A0015] to-black' 
            : 'bg-gradient-to-br from-white via-[#FFE5F1] to-white'
        }`}
      />
      
      {/* Animated orb 1 - Top left */}
      <motion.div
        className={`absolute w-[600px] h-[600px] rounded-full blur-3xl opacity-30 ${
          theme === 'dark' ? 'bg-[#FF006E]' : 'bg-[#FD49A0]'
        }`}
        style={{ top: '-200px', left: '-200px' }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.2, 0.3, 0.2],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Animated orb 2 - Bottom right */}
      <motion.div
        className={`absolute w-[700px] h-[700px] rounded-full blur-3xl opacity-20 ${
          theme === 'dark' ? 'bg-[#C70055]' : 'bg-[#FF006E]'
        }`}
        style={{ bottom: '-300px', right: '-300px' }}
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.15, 0.25, 0.15],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 1,
        }}
      />

      {/* Animated orb 3 - Center */}
      <motion.div
        className={`absolute w-[500px] h-[500px] rounded-full blur-3xl opacity-10 ${
          theme === 'dark' ? 'bg-[#FD49A0]' : 'bg-[#C70055]'
        }`}
        style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
        animate={{
          scale: [1, 1.1, 1],
          x: [-50, -30, -50],
          y: [-50, -70, -50],
          opacity: [0.1, 0.15, 0.1],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 2,
        }}
      />

      {/* Grid overlay for depth */}
      <div 
        className={`absolute inset-0 opacity-5 ${
          theme === 'dark' ? 'bg-grid-white/[0.02]' : 'bg-grid-black/[0.02]'
        }`}
        style={{
          backgroundImage: `linear-gradient(${theme === 'dark' ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.02)'} 1px, transparent 1px), linear-gradient(90deg, ${theme === 'dark' ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.02)'} 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }}
      />
    </div>
  );
}
