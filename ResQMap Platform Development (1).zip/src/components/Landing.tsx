import { Canvas } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { ImageWithFallback } from './figma/ImageWithFallback';
import logo from 'figma:asset/60266e2cd9c97eec8cf483735fb71816b3fac371.png';

/**
 * 3D Landing Page
 * 
 * Features:
 * - Floating cubic voxels (Minecraft aesthetic)
 * - Physics-based animation
 * - Cinematic intro sequence
 * - HTML overlay with gradient text
 * - ResQMap logo integration
 * 
 * Tech: React-Three-Fiber + Drei
 */

interface FloatingCubeProps {
  position: [number, number, number];
  delay: number;
}

function FloatingCube({ position, delay }: FloatingCubeProps) {
  return (
    <Float
      speed={1.5}
      rotationIntensity={0.5}
      floatIntensity={0.8}
      floatingRange={[-0.5, 0.5]}
    >
      <mesh position={position}>
        <boxGeometry args={[0.4, 0.4, 0.4]} />
        <meshStandardMaterial
          color="#568203"
          emissive="#568203"
          emissiveIntensity={0.4}
          metalness={0.3}
          roughness={0.3}
        />
      </mesh>
    </Float>
  );
}

function Scene3D() {
  return (
    <group>
      {/* Center large cube */}
      <Float speed={0.5} rotationIntensity={0.3} floatIntensity={0.3}>
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[1.5, 1.5, 1.5]} />
          <meshStandardMaterial
            color="#568203"
            emissive="#568203"
            emissiveIntensity={0.5}
            metalness={0.7}
            roughness={0.2}
            wireframe={false}
          />
        </mesh>
      </Float>

      {/* Floating voxel cubes around */}
      <FloatingCube position={[-3, 2, -2]} delay={0} />
      <FloatingCube position={[3, 1.5, -1]} delay={0.2} />
      <FloatingCube position={[-2.5, -1, 1]} delay={0.4} />
      <FloatingCube position={[2.5, -1.5, 0]} delay={0.6} />
      <FloatingCube position={[-3.5, 0, 2]} delay={0.8} />
      <FloatingCube position={[3.5, -0.5, 1.5]} delay={1.0} />
      <FloatingCube position={[-1.5, 2.5, 1]} delay={1.2} />
      <FloatingCube position={[1.5, -2, -1]} delay={1.4} />
      <FloatingCube position={[0, 3, 0]} delay={1.6} />
      <FloatingCube position={[0, -3, 0]} delay={1.8} />
    </group>
  );
}

interface LandingProps {
  onEnter: () => void;
}

export function Landing({ onEnter }: LandingProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* 3D Canvas Background */}
      <Canvas
        camera={{ position: [0, 0, 8], fov: 50 }}
        className="w-full h-full"
        style={{ background: 'linear-gradient(to bottom, #0B2B5A 0%, #1a3a6e 100%)' }}
      >
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#568203" />
        <pointLight position={[10, 10, 10]} intensity={0.3} color="#568203" />
        
        <Scene3D />
      </Canvas>

      {/* Overlay content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="text-center mb-8"
        >
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="flex justify-center mb-6"
          >
            <ImageWithFallback
              src={logo}
              alt="ResQMap Logo"
              className="w-24 h-24"
              style={{
                filter: 'drop-shadow(0 0 20px rgba(86, 130, 3, 0.5))',
              }}
            />
          </motion.div>
          
          {/* Large RESQMAP title with gradient */}
          <h1
            className="text-8xl mb-4 tracking-wider"
            style={{
              background: 'linear-gradient(135deg, #568203 0%, #6a9e04 50%, #568203 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              textShadow: '0 0 40px rgba(86, 130, 3, 0.3)',
              fontWeight: 700
            }}
          >
            RESQMAP
          </h1>
          
          {/* Glowing underline */}
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ delay: 0.5, duration: 1 }}
            className="h-1 mx-auto max-w-md"
            style={{
              background: 'linear-gradient(90deg, transparent, #568203, transparent)',
              boxShadow: '0 0 20px rgba(86, 130, 3, 0.5)'
            }}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="text-center text-[#F7F9FB] pointer-events-auto"
        >
          <h2 className="text-2xl mb-4">Real-Time Disaster Relief Mapping</h2>
          <p className="text-[#F7F9FB]/70 mb-8 max-w-md px-4">
            Live hazard detection • Responder coordination • Crowdsourced intelligence
          </p>
          
          {loading ? (
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="w-5 h-5 animate-spin text-[#568203]" />
              <span>Initializing system...</span>
            </div>
          ) : (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1.5, duration: 0.5 }}
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(86, 130, 3, 0.5)' }}
              whileTap={{ scale: 0.95 }}
              onClick={onEnter}
              className="px-8 py-4 bg-[#568203] hover:bg-[#6a9e04] text-white rounded-lg transition-all duration-300 shadow-lg"
            >
              Enter Command Center
            </motion.button>
          )}
        </motion.div>
      </div>

      {/* Vignette effect */}
      <div 
        className="absolute inset-0 pointer-events-none" 
        style={{
          background: 'radial-gradient(circle at center, transparent 0%, rgba(11, 43, 90, 0.5) 100%)'
        }}
      />
    </div>
  );
}