import { useState } from 'react';
import { motion } from 'motion/react';
import { X, Flame, Droplet, AlertCircle, Building2, Activity, MapPin, Send } from 'lucide-react';
import { useRealtimeData } from '../hooks/useRealtimeData';
import { useAppContext } from '../context/AppContext';

/**
 * Report Creation Sheet
 * 
 * Allows users to submit new hazard reports
 * Features:
 * - Form validation
 * - Location picking
 * - Severity selection
 * - Photo upload (mock)
 * - Real-time submission
 */

interface ReportSheetProps {
  onClose: () => void;
}

const hazardTypes = [
  { id: 'fire', label: 'Fire', icon: Flame, color: '#E94B35' },
  { id: 'flood', label: 'Flood', icon: Droplet, color: '#3B82F6' },
  { id: 'roadblock', label: 'Road Block', icon: AlertCircle, color: '#FF9A00' },
  { id: 'collapse', label: 'Collapse', icon: Building2, color: '#EF4444' },
  { id: 'medical', label: 'Medical', icon: Activity, color: '#10B981' }
] as const;

const severityLevels = [
  { id: 'low', label: 'Low', color: '#568203' },
  { id: 'medium', label: 'Medium', color: '#FF9A00' },
  { id: 'high', label: 'High', color: '#E94B35' },
  { id: 'critical', label: 'Critical', color: '#DC2626' }
] as const;

export function ReportSheet({ onClose }: ReportSheetProps) {
  const { addHazard } = useRealtimeData();
  const { user } = useAppContext();
  
  const [selectedType, setSelectedType] = useState<typeof hazardTypes[number]['id'] | null>(null);
  const [severity, setSeverity] = useState<typeof severityLevels[number]['id']>('medium');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState<[number, number]>([-122.4194, 37.7749]);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedType || !title || !description) {
      alert('Please fill in all required fields');
      return;
    }

    setSubmitting(true);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    addHazard({
      type: selectedType,
      severity,
      location,
      title,
      description,
      reportedBy: user?.name || 'Anonymous',
      affectedRadius: severity === 'critical' ? 500 : severity === 'high' ? 300 : 150
    });

    setSubmitting(false);
    onClose();
  };

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation([position.coords.longitude, position.coords.latitude]);
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Could not get current location. Using default.');
        }
      );
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
        className="w-full max-w-2xl bg-[#0B2B5A] rounded-t-2xl sm:rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-[#0B2B5A] border-b border-white/10 p-6 flex items-center justify-between">
          <h2 className="text-2xl text-[#F7F9FB]">Report Incident</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#F7F9FB]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Hazard Type Selection */}
          <div>
            <label className="block mb-3 text-sm text-[#F7F9FB]/70">
              Incident Type <span className="text-[#E94B35]">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {hazardTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setSelectedType(type.id)}
                    className={`p-4 rounded-lg border-2 transition-all duration-300 ${
                      selectedType === type.id
                        ? 'border-[#568203] bg-[#568203]/20'
                        : 'border-white/10 bg-white/5 hover:border-white/20'
                    }`}
                  >
                    <Icon
                      className="w-6 h-6 mx-auto mb-2"
                      style={{ color: selectedType === type.id ? type.color : '#F7F9FB' }}
                    />
                    <span className="text-xs text-[#F7F9FB]">{type.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Severity */}
          <div>
            <label className="block mb-3 text-sm text-[#F7F9FB]/70">
              Severity Level <span className="text-[#E94B35]">*</span>
            </label>
            <div className="grid grid-cols-4 gap-3">
              {severityLevels.map((level) => (
                <button
                  key={level.id}
                  type="button"
                  onClick={() => setSeverity(level.id)}
                  className={`p-3 rounded-lg border-2 transition-all duration-300 text-sm ${
                    severity === level.id
                      ? 'border-[#568203] bg-[#568203]/20'
                      : 'border-white/10 bg-white/5 hover:border-white/20'
                  }`}
                  style={{
                    borderColor: severity === level.id ? level.color : undefined,
                    backgroundColor: severity === level.id ? `${level.color}20` : undefined
                  }}
                >
                  <span className="text-[#F7F9FB]">{level.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block mb-2 text-sm text-[#F7F9FB]/70">
              Title <span className="text-[#E94B35]">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Brief description of the incident"
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-[#F7F9FB] placeholder:text-[#F7F9FB]/40 focus:outline-none focus:border-[#568203] transition-colors"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block mb-2 text-sm text-[#F7F9FB]/70">
              Description <span className="text-[#E94B35]">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide detailed information about the incident"
              rows={4}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-[#F7F9FB] placeholder:text-[#F7F9FB]/40 focus:outline-none focus:border-[#568203] transition-colors resize-none"
              required
            />
          </div>

          {/* Location */}
          <div>
            <label className="block mb-2 text-sm text-[#F7F9FB]/70">
              Location <span className="text-[#E94B35]">*</span>
            </label>
            <div className="flex gap-3">
              <div className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-[#F7F9FB] text-sm">
                {location[1].toFixed(4)}, {location[0].toFixed(4)}
              </div>
              <button
                type="button"
                onClick={handleUseCurrentLocation}
                className="px-4 py-3 bg-[#568203]/20 border border-[#568203] text-[#568203] rounded-lg hover:bg-[#568203]/30 transition-colors flex items-center gap-2"
              >
                <MapPin className="w-4 h-4" />
                <span className="text-sm">Use Current</span>
              </button>
            </div>
            <p className="mt-2 text-xs text-[#F7F9FB]/50">
              Click on map to change location (feature coming soon)
            </p>
          </div>

          {/* Photo Upload (Mock) */}
          <div>
            <label className="block mb-2 text-sm text-[#F7F9FB]/70">
              Photos (Optional)
            </label>
            <div className="border-2 border-dashed border-white/10 rounded-lg p-8 text-center hover:border-white/20 transition-colors cursor-pointer">
              <p className="text-sm text-[#F7F9FB]/50">
                Click to upload or drag and drop
              </p>
              <p className="text-xs text-[#F7F9FB]/30 mt-1">
                PNG, JPG up to 10MB
              </p>
            </div>
          </div>

          {/* Submit */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-white/5 text-[#F7F9FB] rounded-lg hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || !selectedType || !title || !description}
              className="flex-1 px-6 py-3 bg-[#568203] text-white rounded-lg hover:bg-[#6a9e04] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Submit Report
                </>
              )}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
