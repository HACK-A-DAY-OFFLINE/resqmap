import { motion } from 'motion/react';
import { X, Radio, Navigation, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { useRealtimeData } from '../hooks/useRealtimeData';

/**
 * Agent/Responder Dashboard
 * 
 * Shows live status of all responders:
 * - Current location
 * - Assignment status
 * - ETA to incidents
 * - Communication status
 */

interface AgentDashboardProps {
  onClose: () => void;
}

const responderTypeColors = {
  fire: '#E94B35',
  medical: '#10B981',
  police: '#3B82F6',
  rescue: '#FF9A00'
};

const statusIcons = {
  available: CheckCircle,
  enroute: Navigation,
  onscene: AlertCircle,
  offduty: Clock
};

export function AgentDashboard({ onClose }: AgentDashboardProps) {
  const { responders, hazards } = useRealtimeData();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-4xl bg-[#0B2B5A] rounded-2xl shadow-2xl max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#0B2B5A] border-b border-white/10 p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl text-[#F7F9FB] mb-1">Responder Dashboard</h2>
            <p className="text-sm text-[#F7F9FB]/60">
              {responders.length} active units • {responders.filter(r => r.status === 'available').length} available
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#F7F9FB]" />
          </button>
        </div>

        {/* Responders List */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid gap-4">
            {responders.map((responder) => {
              const StatusIcon = statusIcons[responder.status];
              const assignedHazard = hazards.find(h => h.id === responder.assignedHazard);
              
              return (
                <motion.div
                  key={responder.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white/5 border border-white/10 rounded-lg p-5 hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      {/* Avatar */}
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center text-white"
                        style={{ backgroundColor: responderTypeColors[responder.type] }}
                      >
                        <Radio className="w-5 h-5" />
                      </div>

                      {/* Info */}
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-[#F7F9FB]">{responder.name}</h3>
                          <span
                            className="px-2 py-0.5 rounded text-xs uppercase"
                            style={{
                              backgroundColor: `${responderTypeColors[responder.type]}20`,
                              color: responderTypeColors[responder.type]
                            }}
                          >
                            {responder.type}
                          </span>
                        </div>

                        {/* Status */}
                        <div className="flex items-center gap-2 mb-3">
                          <StatusIcon className={`w-4 h-4 ${
                            responder.status === 'available' ? 'text-[#568203]' :
                            responder.status === 'enroute' ? 'text-[#FF9A00]' :
                            responder.status === 'onscene' ? 'text-[#E94B35]' :
                            'text-[#F7F9FB]/40'
                          }`} />
                          <span className="text-sm text-[#F7F9FB]/70 capitalize">
                            {responder.status.replace('_', ' ')}
                          </span>
                        </div>

                        {/* Assignment */}
                        {assignedHazard && (
                          <div className="bg-white/5 rounded p-3 mb-3">
                            <p className="text-xs text-[#F7F9FB]/50 mb-1">Assigned to:</p>
                            <p className="text-sm text-[#F7F9FB]">{assignedHazard.title}</p>
                            {responder.status === 'enroute' && (
                              <p className="text-xs text-[#FF9A00] mt-1">
                                ETA: ~{Math.floor(Math.random() * 10 + 5)} minutes
                              </p>
                            )}
                          </div>
                        )}

                        {/* Location */}
                        <div className="text-xs text-[#F7F9FB]/40">
                          Last update: {new Date(responder.lastUpdate).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <button className="px-3 py-1.5 bg-[#568203]/20 text-[#568203] rounded text-sm hover:bg-[#568203]/30 transition-colors">
                        Contact
                      </button>
                      <button className="px-3 py-1.5 bg-white/5 text-[#F7F9FB] rounded text-sm hover:bg-white/10 transition-colors">
                        Track
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#0B2B5A] border-t border-white/10 p-4 flex items-center justify-between">
          <div className="text-sm text-[#F7F9FB]/60">
            Real-time updates every 5 seconds
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-[#568203] rounded-full animate-pulse" />
            <span className="text-sm text-[#F7F9FB]/60">Live</span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
