import { useState, useEffect, useCallback } from 'react';

/**
 * Offline Queue Hook
 * 
 * Manages action queuing when offline and syncing when online
 * 
 * Features:
 * - Queue actions locally when offline
 * - Auto-sync when connectivity restored
 * - Retry failed syncs
 * - Action persistence
 * 
 * States:
 * - online: Connected, sync immediately
 * - offline: Disconnected, queue actions
 * - syncing: Uploading queued actions
 * - failed-sync: Sync attempt failed
 */

export interface QueuedAction {
  id: string;
  type: 'responder:action' | 'hazard:report' | 'location:update';
  payload: any;
  timestamp: string;
  retries: number;
  status: 'pending' | 'syncing' | 'synced' | 'failed';
}

export type ConnectionState = 'online' | 'offline' | 'syncing' | 'failed-sync';

const QUEUE_STORAGE_KEY = 'resqmap_offline_queue';
const MAX_RETRIES = 3;

export function useOfflineQueue() {
  const [queue, setQueue] = useState<QueuedAction[]>([]);
  const [connectionState, setConnectionState] = useState<ConnectionState>('online');
  const [isOfflineMode, setIsOfflineMode] = useState(false);

  // Load queue from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(QUEUE_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setQueue(parsed.filter((action: QueuedAction) => action.status !== 'synced'));
      }
    } catch (err) {
      console.error('Failed to load offline queue:', err);
    }
  }, []);

  // Persist queue to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(queue));
    } catch (err) {
      console.error('Failed to persist offline queue:', err);
    }
  }, [queue]);

  // Listen for online/offline events
  useEffect(() => {
    const handleOnline = () => {
      if (!isOfflineMode) {
        setConnectionState('online');
        // Auto-sync when back online
        syncQueue();
      }
    };

    const handleOffline = () => {
      if (!isOfflineMode) {
        setConnectionState('offline');
      }
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [isOfflineMode]);

  // Queue an action
  const queueAction = useCallback((type: QueuedAction['type'], payload: any) => {
    const action: QueuedAction = {
      id: `action-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      payload,
      timestamp: new Date().toISOString(),
      retries: 0,
      status: 'pending'
    };

    setQueue(prev => [...prev, action]);

    // If online and not in offline mode, sync immediately
    if (connectionState === 'online' && !isOfflineMode) {
      syncAction(action);
    }

    return action.id;
  }, [connectionState, isOfflineMode]);

  // Sync a single action
  const syncAction = async (action: QueuedAction): Promise<boolean> => {
    // Mark as syncing
    setQueue(prev => prev.map(a => 
      a.id === action.id ? { ...a, status: 'syncing' as const } : a
    ));

    try {
      // Simulate API call
      await new Promise<void>((resolve, reject) => {
        setTimeout(() => {
          // 90% success rate for demo
          if (Math.random() > 0.1) {
            resolve();
          } else {
            reject(new Error('Network error'));
          }
        }, 1000);
      });

      // Mark as synced
      setQueue(prev => prev.map(a => 
        a.id === action.id ? { ...a, status: 'synced' as const } : a
      ));

      // Emit sync success event
      window.dispatchEvent(new CustomEvent('queue:synced', { 
        detail: { actionId: action.id, type: action.type } 
      }));

      return true;
    } catch (err) {
      // Increment retries
      const newRetries = action.retries + 1;
      
      if (newRetries >= MAX_RETRIES) {
        // Max retries reached, mark as failed
        setQueue(prev => prev.map(a => 
          a.id === action.id 
            ? { ...a, status: 'failed' as const, retries: newRetries } 
            : a
        ));
      } else {
        // Mark as pending for retry
        setQueue(prev => prev.map(a => 
          a.id === action.id 
            ? { ...a, status: 'pending' as const, retries: newRetries } 
            : a
        ));
      }

      // Emit sync failure event
      window.dispatchEvent(new CustomEvent('queue:sync-failed', { 
        detail: { actionId: action.id, error: err } 
      }));

      return false;
    }
  };

  // Sync all pending actions
  const syncQueue = useCallback(async () => {
    const pendingActions = queue.filter(a => a.status === 'pending');
    
    if (pendingActions.length === 0) {
      return;
    }

    setConnectionState('syncing');

    let allSuccess = true;
    for (const action of pendingActions) {
      const success = await syncAction(action);
      if (!success) {
        allSuccess = false;
      }
    }

    if (allSuccess) {
      setConnectionState('online');
      // Remove synced actions after a delay
      setTimeout(() => {
        setQueue(prev => prev.filter(a => a.status !== 'synced'));
      }, 3000);
    } else {
      setConnectionState('failed-sync');
      // Retry after 5 seconds
      setTimeout(() => {
        if (connectionState !== 'offline') {
          syncQueue();
        }
      }, 5000);
    }
  }, [queue, connectionState]);

  // Toggle offline mode
  const toggleOfflineMode = useCallback((enabled?: boolean) => {
    const newState = enabled !== undefined ? enabled : !isOfflineMode;
    setIsOfflineMode(newState);
    
    if (newState) {
      setConnectionState('offline');
    } else {
      setConnectionState('online');
      // Sync when exiting offline mode
      if (queue.some(a => a.status === 'pending')) {
        syncQueue();
      }
    }
  }, [isOfflineMode, queue, syncQueue]);

  // Clear synced actions
  const clearSyncedActions = useCallback(() => {
    setQueue(prev => prev.filter(a => a.status !== 'synced'));
  }, []);

  // Retry failed actions
  const retryFailedActions = useCallback(() => {
    setQueue(prev => prev.map(a => 
      a.status === 'failed' ? { ...a, status: 'pending' as const, retries: 0 } : a
    ));
    
    if (connectionState === 'online') {
      syncQueue();
    }
  }, [connectionState, syncQueue]);

  return {
    queue,
    connectionState,
    isOfflineMode,
    pendingCount: queue.filter(a => a.status === 'pending').length,
    failedCount: queue.filter(a => a.status === 'failed').length,
    queueAction,
    syncQueue,
    toggleOfflineMode,
    clearSyncedActions,
    retryFailedActions
  };
}
