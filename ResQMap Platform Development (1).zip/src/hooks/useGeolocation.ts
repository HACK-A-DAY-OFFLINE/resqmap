import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Geolocation Hook
 * 
 * Provides real-time location tracking with manual override capability
 * 
 * Features:
 * - watchPosition for continuous updates
 * - Permission handling
 * - Manual coordinate override
 * - Pause/resume functionality
 * - Error handling
 * 
 * Events emitted:
 * - location:update - when coordinates change
 * - location:error - when geolocation fails
 * - location:permission - when permission state changes
 */

export interface Coordinates {
  lat: number;
  lng: number;
  accuracy?: number;
  timestamp: number;
}

export type GeolocationPermission = 'prompt' | 'granted' | 'denied' | 'unavailable';
export type LocationMode = 'live' | 'manual' | 'paused';

interface UseGeolocationOptions {
  enableHighAccuracy?: boolean;
  maximumAge?: number;
  timeout?: number;
  onUpdate?: (coords: Coordinates) => void;
  onError?: (error: string) => void;
}

export function useGeolocation(options: UseGeolocationOptions = {}) {
  const {
    enableHighAccuracy = true,
    maximumAge = 0,
    timeout = 10000,
    onUpdate,
    onError
  } = options;

  const [coordinates, setCoordinates] = useState<Coordinates | null>(null);
  const [permission, setPermission] = useState<GeolocationPermission>('prompt');
  const [mode, setMode] = useState<LocationMode>('paused');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const watchIdRef = useRef<number | null>(null);

  // Check if geolocation is available
  useEffect(() => {
    if (!('geolocation' in navigator)) {
      setPermission('unavailable');
      setError('Geolocation is not supported by your browser');
    }
  }, []);

  // Request permission and start tracking
  const requestPermission = useCallback(async () => {
    if (!('geolocation' in navigator)) {
      setPermission('unavailable');
      setError('Geolocation is not supported');
      onError?.('Geolocation is not supported');
      return false;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Try to get current position to trigger permission prompt
      await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy,
          timeout,
          maximumAge
        });
      });

      setPermission('granted');
      setIsLoading(false);
      return true;
    } catch (err) {
      const geolocationError = err as GeolocationPositionError;
      
      if (geolocationError.code === geolocationError.PERMISSION_DENIED) {
        setPermission('denied');
        setError('Location permission denied');
        onError?.('Location permission denied');
      } else if (geolocationError.code === geolocationError.TIMEOUT) {
        setError('Location request timed out');
        onError?.('Location request timed out');
      } else {
        setError('Unable to retrieve location');
        onError?.('Unable to retrieve location');
      }
      
      setIsLoading(false);
      return false;
    }
  }, [enableHighAccuracy, timeout, maximumAge, onError]);

  // Start live tracking
  const startTracking = useCallback(() => {
    if (mode === 'live' || !('geolocation' in navigator)) {
      return;
    }

    // Clear existing watch
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
    }

    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        const coords: Coordinates = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp
        };
        
        setCoordinates(coords);
        setError(null);
        setMode('live');
        onUpdate?.(coords);
        
        // Emit custom event
        window.dispatchEvent(new CustomEvent('location:update', { detail: coords }));
      },
      (err) => {
        const errorMessage = err.code === err.PERMISSION_DENIED
          ? 'Location permission denied'
          : err.code === err.TIMEOUT
          ? 'Location request timed out'
          : 'Unable to retrieve location';
        
        setError(errorMessage);
        onError?.(errorMessage);
        
        window.dispatchEvent(new CustomEvent('location:error', { detail: errorMessage }));
      },
      {
        enableHighAccuracy,
        maximumAge,
        timeout
      }
    );

    watchIdRef.current = watchId;
  }, [mode, enableHighAccuracy, maximumAge, timeout, onUpdate, onError]);

  // Stop live tracking
  const stopTracking = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setMode('paused');
  }, []);

  // Set manual coordinates
  const setManualCoordinates = useCallback((lat: number, lng: number) => {
    // Stop live tracking when manual coordinates are set
    stopTracking();
    
    const coords: Coordinates = {
      lat,
      lng,
      timestamp: Date.now()
    };
    
    setCoordinates(coords);
    setMode('manual');
    setError(null);
    onUpdate?.(coords);
    
    // Emit custom event
    window.dispatchEvent(new CustomEvent('location:update', { detail: coords }));
  }, [stopTracking, onUpdate]);

  // Resume live tracking after manual override
  const resumeLiveTracking = useCallback(async () => {
    const hasPermission = await requestPermission();
    if (hasPermission) {
      startTracking();
    }
  }, [requestPermission, startTracking]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  return {
    coordinates,
    permission,
    mode,
    error,
    isLoading,
    requestPermission,
    startTracking,
    stopTracking,
    setManualCoordinates,
    resumeLiveTracking
  };
}
