
  # ResQMap Platform Development

  This is a code bundle for ResQMap Platform Development. The original project is available at https://www.figma.com/design/rmcag8ge4evsIUl4Zu7sHV/ResQMap-Platform-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  