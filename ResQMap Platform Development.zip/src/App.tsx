import { useState, useEffect } from 'react';
import { Landing } from './components/Landing';
import { DisasterMap } from './components/DisasterMap';
import { ReportSheet } from './components/ReportSheet';
import { AgentDashboard } from './components/AgentDashboard';
import { EvacuationMode } from './components/EvacuationMode';
import { Settings } from './components/Settings';
import { useRealtimeData } from './hooks/useRealtimeData';
import { AppProvider } from './context/AppContext';

/**
 * ResQMap - Real-time Disaster Relief Mapping Platform
 * 
 * Architecture:
 * - Frontend: React 18 + TypeScript + Tailwind + Motion
 * - 3D: React-Three-Fiber + Drei
 * - Maps: Mapbox GL JS + deck.gl
 * - State: Context API + Mock Realtime (Supabase-ready)
 * 
 * Color Palette:
 * - Primary (Safe): #568203
 * - Dark Navy: #0B2B5A
 * - Hazard Red: #E94B35
 * - Caution Amber: #FF9A00
 * - Neutral: #F7F9FB
 */

type Screen = 'landing' | 'map' | 'evacuation' | 'settings';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [showReportSheet, setShowReportSheet] = useState(false);
  const [showAgentDashboard, setShowAgentDashboard] = useState(false);
  const [evacuationActive, setEvacuationActive] = useState(false);

  // Auto-transition from landing to map after 3 seconds
  useEffect(() => {
    if (currentScreen === 'landing') {
      const timer = setTimeout(() => {
        setCurrentScreen('map');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [currentScreen]);

  // Check for high-severity alerts (mock logic)
  const { hazards } = useRealtimeData();
  useEffect(() => {
    const criticalHazards = hazards.filter(h => h.severity === 'critical');
    if (criticalHazards.length > 0 && !evacuationActive) {
      // Auto-trigger evacuation mode for demo
      // In production, this would be based on complex alert rules
    }
  }, [hazards, evacuationActive]);

  return (
    <AppProvider>
      <div className="w-full h-screen overflow-hidden bg-[#0B2B5A]">
        {/* Landing Screen */}
        {currentScreen === 'landing' && (
          <Landing onEnter={() => setCurrentScreen('map')} />
        )}

        {/* Main Map View */}
        {currentScreen === 'map' && !evacuationActive && (
          <DisasterMap
            onCreateReport={() => setShowReportSheet(true)}
            onOpenAgents={() => setShowAgentDashboard(true)}
            onOpenSettings={() => setCurrentScreen('settings')}
            onEvacuate={() => setEvacuationActive(true)}
          />
        )}

        {/* Evacuation Mode */}
        {evacuationActive && (
          <EvacuationMode
            onClose={() => setEvacuationActive(false)}
            onBackToMap={() => {
              setEvacuationActive(false);
              setCurrentScreen('map');
            }}
          />
        )}

        {/* Settings Screen */}
        {currentScreen === 'settings' && (
          <Settings onBack={() => setCurrentScreen('map')} />
        )}

        {/* Report Creation Sheet (Modal) */}
        {showReportSheet && (
          <ReportSheet onClose={() => setShowReportSheet(false)} />
        )}

        {/* Agent Dashboard Overlay */}
        {showAgentDashboard && (
          <AgentDashboard onClose={() => setShowAgentDashboard(false)} />
        )}
      </div>
    </AppProvider>
  );
}
