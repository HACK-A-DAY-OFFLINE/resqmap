# ResQMap - Real-Time Disaster Relief Mapping Platform

## 🚨 Overview

ResQMap is a production-grade real-time disaster relief mapping system designed for emergency response coordination. The platform combines live hazard detection, 3D visualization, GIS mapping, and responder tracking into a unified intelligence dashboard.

## ✨ Features

### Core Capabilities
- **Real-Time Hazard Tracking** - Live updates for fires, floods, road blocks, building collapses, and medical emergencies
- **3D Animated Landing** - Cinematic intro with React-Three-Fiber and floating physics
- **Interactive GIS Mapping** - Powered by Mapbox GL JS with animated markers
- **Responder Dashboard** - Live tracking of emergency personnel with status updates
- **Evacuation Mode** - Critical alert UI with route guidance
- **Report Creation** - Crowdsourced incident reporting with validation
- **Offline Mode** - Cached map data for low-connectivity scenarios
- **Settings & Customization** - Theme, notifications, and accessibility options

### Technical Highlights
- ⚡ Built with React 18 + TypeScript (strict mode)
- 🎨 Tailwind CSS with custom design system
- 🌐 Mapbox GL JS for professional mapping
- 🎭 Motion (Framer Motion) for smooth animations
- 🎲 React-Three-Fiber for 3D graphics
- 📡 Mock real-time updates (Supabase-ready architecture)
- ♿ Accessibility-first with reduced motion support

## 🎨 Design System

### Color Palette
```css
Primary (Safe):    #568203  /* Avocado green */
Dark Navy:         #0B2B5A  /* Background */
Hazard Red:        #E94B35  /* Critical alerts */
Caution Amber:     #FF9A00  /* Warnings */
Neutral:           #F7F9FB  /* Text/UI */
```

### Motion Principles
- 300-350ms easeOutQuint transitions
- Bouncy physics for floating elements
- Cinematic hero intro sequences
- Reduced-motion fallback for accessibility

## 🏗️ Architecture

### Project Structure
```
/
├── App.tsx                      # Main app router
├── context/
│   └── AppContext.tsx           # Global state management
├── hooks/
│   └── useRealtimeData.ts       # Mock realtime data (Supabase-ready)
├── components/
│   ├── Landing.tsx              # 3D landing page
│   ├── DisasterMap.tsx          # Main map view
│   ├── ReportSheet.tsx          # Incident reporting
│   ├── AgentDashboard.tsx       # Responder tracking
│   ├── EvacuationMode.tsx       # High-severity alerts
│   └── Settings.tsx             # User preferences
└── styles/
    └── globals.css              # Design tokens & animations
```

### Data Flow
```
User Interaction
      ���
  React Components
      ↓
  Context API (State)
      ↓
  useRealtimeData Hook (Mock → Supabase)
      ↓
  UI Updates (Motion animations)
```

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ or compatible runtime
- Mapbox account (free tier available)
- (Optional) Supabase account for real backend

### Development

This is a frontend prototype running in Figma Make. All dependencies are automatically imported:

```typescript
// Already available:
import { motion } from 'motion/react';
import mapboxgl from 'mapbox-gl';
import { Canvas } from '@react-three/fiber';
import { useRealtimeData } from './hooks/useRealtimeData';
```

### Mapbox Configuration

⚠️ **Important**: Replace the Mapbox token in `/components/DisasterMap.tsx`:

```typescript
// Line 40
const MAPBOX_TOKEN = 'pk.YOUR_MAPBOX_TOKEN_HERE';
```

Get your free token at: https://mapbox.com

## 📡 Backend Integration (Supabase)

The application is architected for easy Supabase integration. Here's how to connect:

### 1. Schema Setup
```sql
-- Hazards table
CREATE TABLE hazards (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type TEXT NOT NULL,
  severity TEXT NOT NULL,
  location GEOGRAPHY(POINT) NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  reported_at TIMESTAMPTZ DEFAULT NOW(),
  reported_by TEXT,
  status TEXT DEFAULT 'active',
  affected_radius INT
);

-- Responders table
CREATE TABLE responders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  location GEOGRAPHY(POINT) NOT NULL,
  status TEXT DEFAULT 'available',
  assigned_hazard UUID REFERENCES hazards(id),
  last_update TIMESTAMPTZ DEFAULT NOW()
);

-- Enable PostGIS for geospatial queries
CREATE EXTENSION IF NOT EXISTS postgis;

-- Create spatial index
CREATE INDEX hazards_location_idx ON hazards USING GIST(location);
CREATE INDEX responders_location_idx ON responders USING GIST(location);
```

### 2. Replace Mock Data Hook
```typescript
// hooks/useRealtimeData.ts
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export function useRealtimeData() {
  const [hazards, setHazards] = useState<Hazard[]>([]);

  useEffect(() => {
    // Initial fetch
    supabase
      .from('hazards')
      .select('*')
      .eq('status', 'active')
      .then(({ data }) => setHazards(data || []));

    // Subscribe to changes
    const channel = supabase
      .channel('hazards-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'hazards'
      }, (payload) => {
        // Handle insert/update/delete
        if (payload.eventType === 'INSERT') {
          setHazards(prev => [...prev, payload.new as Hazard]);
        }
        // ... handle other events
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return { hazards, responders, crowdDensity };
}
```

### 3. Row-Level Security
```sql
-- Enable RLS
ALTER TABLE hazards ENABLE ROW LEVEL SECURITY;
ALTER TABLE responders ENABLE ROW LEVEL SECURITY;

-- Public read access for active hazards
CREATE POLICY "Public read active hazards"
  ON hazards FOR SELECT
  USING (status = 'active');

-- Authenticated users can report hazards
CREATE POLICY "Authenticated users can insert hazards"
  ON hazards FOR INSERT
  WITH CHECK (auth.role() = 'authenticated');
```

## 🔐 Security Considerations

### Input Sanitization
All user inputs are validated and sanitized:
- Title/description length limits
- Location coordinate validation
- Hazard type enum enforcement

### Rate Limiting
Implement rate limiting for report submission:
```typescript
// Recommended: 5 reports per user per hour
const RATE_LIMIT = 5;
const RATE_WINDOW = 3600000; // 1 hour in ms
```

### API Key Protection
- Never commit API keys to version control
- Use environment variables for secrets
- Implement key rotation policies

## 🧪 Testing Strategy

### Unit Tests (Recommended)
```typescript
// Example with Vitest
import { describe, it, expect } from 'vitest';
import { useRealtimeData } from './hooks/useRealtimeData';

describe('useRealtimeData', () => {
  it('should filter critical hazards', () => {
    const { hazards } = useRealtimeData();
    const critical = hazards.filter(h => h.severity === 'critical');
    expect(critical.length).toBeGreaterThan(0);
  });
});
```

### E2E Tests (Recommended)
```typescript
// Example with Playwright
import { test, expect } from '@playwright/test';

test('user can create hazard report', async ({ page }) => {
  await page.goto('/');
  await page.click('button[aria-label="Create Report"]');
  await page.fill('input[name="title"]', 'Test Fire');
  await page.selectOption('select[name="type"]', 'fire');
  await page.click('button[type="submit"]');
  await expect(page.locator('.hazard-marker')).toBeVisible();
});
```

## 📱 Responsive Design

The application adapts to different screen sizes:
- **Desktop (1920x1080+)**: Full dashboard with side panels
- **Tablet (768-1920px)**: Stacked layout with collapsible panels
- **Mobile (320-768px)**: Bottom sheets and full-screen modes

## ♿ Accessibility

- WCAG 2.1 AA compliant color contrast
- Keyboard navigation support
- Screen reader optimized
- Reduced motion mode
- Focus indicators on all interactive elements

## 🚀 Performance Optimization

### Current Optimizations
- React.memo for expensive components
- Lazy loading for 3D assets
- Debounced map updates
- Virtual scrolling for long lists

### Recommended Additional Optimizations
- Implement code splitting: `React.lazy(() => import('./components/Landing'))`
- Add service worker for offline support
- Use IndexedDB for local caching
- Implement WebSocket connection pooling

## 📊 Monitoring & Analytics

### Recommended Metrics
- **Uptime**: Map load success rate
- **Performance**: Time to interactive (TTI)
- **Engagement**: Reports submitted per session
- **Errors**: Failed API calls, rendering errors

### Suggested Tools
- Sentry for error tracking
- PostHog for analytics
- Lighthouse CI for performance
- LogRocket for session replay

## 🔄 Deployment

### Production Checklist
- [ ] Replace Mapbox token with production key
- [ ] Connect Supabase backend
- [ ] Enable HTTPS
- [ ] Configure CORS policies
- [ ] Set up CDN for static assets
- [ ] Enable caching headers
- [ ] Configure rate limiting
- [ ] Set up monitoring/alerting
- [ ] Run security audit
- [ ] Load test with 1000+ concurrent users

### Environment Variables
```bash
MAPBOX_TOKEN=pk.your_production_token
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key
```

## 🤝 Contributing

### Code Style
- Use TypeScript strict mode
- Follow Airbnb React style guide
- Write descriptive commit messages
- Add JSDoc comments for complex functions

### Pull Request Process
1. Create feature branch from `main`
2. Write tests for new features
3. Update documentation
4. Ensure all tests pass
5. Request code review

## 📄 License

This is a demo/prototype application. For production use, ensure compliance with:
- Mapbox Terms of Service
- Data privacy regulations (GDPR, CCPA)
- Emergency services coordination guidelines

## 🆘 Support

### Known Issues
- Mapbox requires valid token to display map
- 3D landing may not render on low-end devices
- Geolocation requires HTTPS in production

### Troubleshooting

**Map not displaying?**
- Check Mapbox token is valid
- Verify browser console for errors
- Ensure `mapbox-gl` CSS is imported

**3D scene not loading?**
- Check WebGL support: `navigator.gpu`
- Try disabling hardware acceleration
- Fall back to 2D mode on mobile

**Performance issues?**
- Enable reduced motion in settings
- Reduce map marker density
- Clear browser cache

## 🔮 Roadmap

### Phase 1 (Current)
- ✅ Frontend prototype
- ✅ Mock real-time data
- ✅ 3D landing page
- ✅ Basic map interactions

### Phase 2 (Next)
- [ ] Supabase integration
- [ ] WebSocket real-time updates
- [ ] Push notifications
- [ ] PWA support

### Phase 3 (Future)
- [ ] Mobile apps (React Native)
- [ ] ML-based hazard prediction
- [ ] Multi-language support
- [ ] Advanced analytics dashboard

## 🙏 Acknowledgments

Built with:
- React & TypeScript
- Tailwind CSS
- Mapbox GL JS
- React-Three-Fiber
- Motion (Framer Motion)
- Lucide React Icons

Inspired by real-world disaster relief coordination systems and emergency management platforms.

---

**Built with ❤️ for emergency responders worldwide**

For questions or feedback, please open an issue or contact the development team.
