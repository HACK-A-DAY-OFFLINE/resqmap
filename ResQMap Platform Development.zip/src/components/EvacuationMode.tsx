import { motion } from 'motion/react';
import { AlertTriangle, Navigation, ArrowRight, X, Radio } from 'lucide-react';
import { useEffect, useState } from 'react';

/**
 * Evacuation Mode
 * 
 * High-severity alert UI triggered during critical incidents
 * Features:
 * - Dramatic red alert theme
 * - Evacuation route guidance
 * - Safe zone recommendations
 * - Emergency contacts
 * - Live updates
 */

interface EvacuationModeProps {
  onClose: () => void;
  onBackToMap: () => void;
}

const evacuationRoutes = [
  {
    id: 'route1',
    name: 'North Route via Market St',
    distance: '2.3 km',
    eta: '15 min',
    crowdLevel: 'low',
    safeZone: 'Golden Gate Park Assembly Point',
    status: 'recommended'
  },
  {
    id: 'route2',
    name: 'West Route via Geary Blvd',
    distance: '3.1 km',
    eta: '20 min',
    crowdLevel: 'medium',
    safeZone: 'Ocean Beach Evacuation Center',
    status: 'available'
  },
  {
    id: 'route3',
    name: 'East Route via Bay Bridge',
    distance: '4.5 km',
    eta: '35 min',
    crowdLevel: 'high',
    safeZone: 'Oakland Emergency Shelter',
    status: 'congested'
  }
];

const emergencyContacts = [
  { name: 'Emergency Services', number: '911' },
  { name: 'SF Emergency Management', number: '415-558-2700' },
  { name: 'Red Cross Disaster Relief', number: '1-800-RED-CROSS' }
];

export function EvacuationMode({ onClose, onBackToMap }: EvacuationModeProps) {
  const [countdown, setCountdown] = useState(10);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (dismissed) return;
    
    const interval = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          return 10; // Reset
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [dismissed]);

  return (
    <div className="w-full h-full bg-gradient-to-b from-[#E94B35] to-[#DC2626] overflow-y-auto">
      {/* Pulsing alert header */}
      <motion.div
        animate={{ opacity: [1, 0.7, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="bg-[#DC2626] border-b-4 border-white/20"
      >
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
              >
                <AlertTriangle className="w-12 h-12 text-white" />
              </motion.div>
              <div>
                <h1 className="text-3xl text-white mb-1">EVACUATION ALERT</h1>
                <p className="text-white/90">Critical incident detected - Immediate action required</p>
              </div>
            </div>
            <button
              onClick={() => {
                setDismissed(true);
                onClose();
              }}
              className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
            >
              <X className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* Main content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Alert message */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 mb-8 text-white"
        >
          <div className="flex items-start gap-6">
            <div className="flex-1">
              <h2 className="text-2xl mb-4">Critical Fire Event - Mission District</h2>
              <p className="text-white/90 mb-4">
                A major structure fire has been reported with potential for rapid spread. 
                Residents within a 500-meter radius are advised to evacuate immediately.
              </p>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Radio className="w-4 h-4" />
                  <span>Last update: {new Date().toLocaleTimeString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                  <span>Next update in {countdown}s</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Evacuation routes */}
        <div className="mb-8">
          <h2 className="text-2xl text-white mb-4">Recommended Evacuation Routes</h2>
          <div className="grid gap-4">
            {evacuationRoutes.map((route, index) => (
              <motion.div
                key={route.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white/10 backdrop-blur-md border rounded-xl p-6 ${
                  route.status === 'recommended' 
                    ? 'border-[#568203] bg-[#568203]/20' 
                    : 'border-white/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <Navigation className="w-5 h-5 text-white" />
                      <h3 className="text-lg text-white">{route.name}</h3>
                      {route.status === 'recommended' && (
                        <span className="px-2 py-1 bg-[#568203] text-white text-xs rounded-full">
                          RECOMMENDED
                        </span>
                      )}
                      {route.status === 'congested' && (
                        <span className="px-2 py-1 bg-[#FF9A00] text-white text-xs rounded-full">
                          CONGESTED
                        </span>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mb-4 text-sm text-white/90">
                      <div>
                        <span className="text-white/60">Distance:</span> {route.distance}
                      </div>
                      <div>
                        <span className="text-white/60">ETA:</span> {route.eta}
                      </div>
                      <div>
                        <span className="text-white/60">Traffic:</span>{' '}
                        <span className={
                          route.crowdLevel === 'low' ? 'text-[#568203]' :
                          route.crowdLevel === 'medium' ? 'text-[#FF9A00]' :
                          'text-[#E94B35]'
                        }>
                          {route.crowdLevel.toUpperCase()}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-white/80">
                      <ArrowRight className="w-4 h-4" />
                      <span>Safe Zone: {route.safeZone}</span>
                    </div>
                  </div>

                  <button className="ml-6 px-6 py-3 bg-white text-[#E94B35] rounded-lg hover:bg-white/90 transition-colors whitespace-nowrap">
                    Start Navigation
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Emergency contacts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6"
        >
          <h2 className="text-xl text-white mb-4">Emergency Contacts</h2>
          <div className="grid sm:grid-cols-3 gap-4">
            {emergencyContacts.map((contact) => (
              <a
                key={contact.name}
                href={`tel:${contact.number}`}
                className="flex items-center justify-between p-4 bg-white/10 rounded-lg hover:bg-white/20 transition-colors text-white"
              >
                <div>
                  <div className="text-sm text-white/70">{contact.name}</div>
                  <div className="text-lg">{contact.number}</div>
                </div>
                <ArrowRight className="w-5 h-5" />
              </a>
            ))}
          </div>
        </motion.div>

        {/* Action buttons */}
        <div className="flex gap-4 mt-8">
          <button
            onClick={onBackToMap}
            className="flex-1 px-6 py-4 bg-white/20 hover:bg-white/30 text-white rounded-lg transition-colors"
          >
            View Full Map
          </button>
          <button
            onClick={() => {
              setDismissed(true);
              onClose();
            }}
            className="flex-1 px-6 py-4 bg-white text-[#E94B35] hover:bg-white/90 rounded-lg transition-colors"
          >
            Acknowledge & Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}
