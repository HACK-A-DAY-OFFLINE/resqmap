import { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Plus, Users, Settings, Radio, Flame, Droplet, Construction, Building2, Activity } from 'lucide-react';
import { useRealtimeData } from '../hooks/useRealtimeData';
import { useAppContext } from '../context/AppContext';

/**
 * Main Disaster Map Component
 * 
 * Features:
 * - MapLibre GL JS integration (open-source, no token required)
 * - Animated pulsing hazard markers
 * - Real-time responder tracking with tweening
 * - Interactive hazard details
 */

interface DisasterMapProps {
  onCreateReport: () => void;
  onOpenAgents: () => void;
  onOpenSettings: () => void;
  onEvacuate: () => void;
}

const hazardIcons = {
  fire: Flame,
  flood: Droplet,
  roadblock: Construction,
  collapse: Building2,
  medical: Activity
};

const hazardColors = {
  fire: '#E94B35',
  flood: '#3B82F6',
  roadblock: '#FF9A00',
  collapse: '#EF4444',
  medical: '#10B981'
};

export function DisasterMap({
  onCreateReport,
  onOpenAgents,
  onOpenSettings,
  onEvacuate
}: DisasterMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<{ [key: string]: maplibregl.Marker }>({});
  const responderMarkersRef = useRef<{ [key: string]: maplibregl.Marker }>({});
  
  const { hazards, responders } = useRealtimeData();
  const { connectionStatus } = useAppContext();
  
  const [selectedHazard, setSelectedHazard] = useState<string | null>(null);
  const [mapLoaded, setMapLoaded] = useState(false);

  // Initialize MapLibre map
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const map = new maplibregl.Map({
      container: mapContainerRef.current,
      style: {
        version: 8,
        sources: {
          'osm': {
            type: 'raster',
            tiles: ['https://a.tile.openstreetmap.org/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '&copy; OpenStreetMap Contributors'
          }
        },
        layers: [
          {
            id: 'osm',
            type: 'raster',
            source: 'osm',
            minzoom: 0,
            maxzoom: 19
          }
        ]
      },
      center: [-122.4194, 37.7749], // San Francisco
      zoom: 12
    });

    map.on('load', () => {
      setMapLoaded(true);
    });

    map.addControl(new maplibregl.NavigationControl(), 'top-right');
    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update hazard markers
  useEffect(() => {
    if (!mapRef.current || !mapLoaded) return;

    // Remove markers that no longer exist
    Object.keys(markersRef.current).forEach(id => {
      if (!hazards.find(h => h.id === id)) {
        markersRef.current[id].remove();
        delete markersRef.current[id];
      }
    });

    // Add or update markers
    hazards.forEach(hazard => {
      if (markersRef.current[hazard.id]) {
        // Update existing marker position
        markersRef.current[hazard.id].setLngLat(hazard.location);
      } else {
        // Create new marker with custom HTML
        const el = document.createElement('div');
        el.className = 'hazard-marker';
        el.style.width = '40px';
        el.style.height = '40px';
        el.style.cursor = 'pointer';
        
        const Icon = hazardIcons[hazard.type];
        const color = hazardColors[hazard.type];
        
        el.innerHTML = `
          <div class="relative w-full h-full">
            <div class="absolute inset-0 rounded-full animate-ping opacity-75" style="background-color: ${color}"></div>
            <div class="relative w-full h-full rounded-full flex items-center justify-center" style="background-color: ${color}">
              <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                ${Icon === Flame ? '<path stroke-linecap="round" stroke-linejoin="round" d="M15.362 5.214A8.252 8.252 0 0112 21 8.25 8.25 0 016.038 7.048 8.287 8.287 0 009 9.6a8.983 8.983 0 013.361-6.867 8.21 8.21 0 003 2.48z" />' : ''}
                ${Icon === Droplet ? '<path stroke-linecap="round" stroke-linejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />' : ''}
                ${Icon === Construction ? '<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />' : ''}
                ${Icon === Building2 ? '<path stroke-linecap="round" stroke-linejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21M3 3h12m-.75 4.5H21m-3.75 3.75h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008z" />' : ''}
                ${Icon === Activity ? '<path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />' : ''}
              </svg>
            </div>
          </div>
        `;

        el.addEventListener('click', () => {
          setSelectedHazard(hazard.id);
        });

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat(hazard.location)
          .addTo(mapRef.current!);

        markersRef.current[hazard.id] = marker;
      }
    });
  }, [hazards, mapLoaded]);

  // Update responder markers
  useEffect(() => {
    if (!mapRef.current || !mapLoaded) return;

    // Remove markers that no longer exist
    Object.keys(responderMarkersRef.current).forEach(id => {
      if (!responders.find(r => r.id === id)) {
        responderMarkersRef.current[id].remove();
        delete responderMarkersRef.current[id];
      }
    });

    responders.forEach(responder => {
      if (responderMarkersRef.current[responder.id]) {
        // Animate to new position
        responderMarkersRef.current[responder.id].setLngLat(responder.location);
      } else {
        // Create new responder marker
        const el = document.createElement('div');
        el.className = 'responder-marker';
        el.style.width = '30px';
        el.style.height = '30px';
        
        const statusColor = responder.status === 'available' ? '#568203' : 
                          responder.status === 'enroute' ? '#FF9A00' : '#E94B35';
        
        el.innerHTML = `
          <div class="w-full h-full rounded-full border-2 border-white shadow-lg flex items-center justify-center" style="background-color: ${statusColor}">
            <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />
            </svg>
          </div>
        `;

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat(responder.location)
          .addTo(mapRef.current!);

        responderMarkersRef.current[responder.id] = marker;
      }
    });
  }, [responders, mapLoaded]);

  const selectedHazardData = hazards.find(h => h.id === selectedHazard);

  return (
    <div className="relative w-full h-full">
      {/* Map container */}
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-[#0B2B5A]/90 to-transparent pointer-events-none">
        <div className="flex items-center justify-between max-w-7xl mx-auto pointer-events-auto">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl text-[#F7F9FB]">RESQMAP</h1>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-[#568203]/20 border border-[#568203] rounded-full">
              <div className={`w-2 h-2 rounded-full animate-pulse ${
                connectionStatus === 'connected' ? 'bg-[#568203]' : 
                connectionStatus === 'connecting' ? 'bg-[#FF9A00]' : 'bg-[#E94B35]'
              }`} />
              <span className="text-sm text-[#F7F9FB]">{connectionStatus}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenAgents}
              className="p-2.5 bg-[#0B2B5A]/80 hover:bg-[#0B2B5A] text-[#F7F9FB] rounded-lg transition-all duration-300 backdrop-blur-sm"
            >
              <Users className="w-5 h-5" />
            </button>
            <button
              onClick={onOpenSettings}
              className="p-2.5 bg-[#0B2B5A]/80 hover:bg-[#0B2B5A] text-[#F7F9FB] rounded-lg transition-all duration-300 backdrop-blur-sm"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Stats panel */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="absolute top-24 left-4 bg-[#0B2B5A]/90 backdrop-blur-md rounded-lg p-4 text-[#F7F9FB] shadow-lg min-w-[200px]"
      >
        <h3 className="mb-3 flex items-center gap-2">
          <Radio className="w-4 h-4 text-[#568203]" />
          Live Status
        </h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-[#F7F9FB]/70">Active Hazards</span>
            <span className="text-[#E94B35]">{hazards.filter(h => h.status === 'active').length}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#F7F9FB]/70">Responders</span>
            <span className="text-[#568203]">{responders.length}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#F7F9FB]/70">Critical</span>
            <span className="text-[#E94B35]">{hazards.filter(h => h.severity === 'critical').length}</span>
          </div>
        </div>
      </motion.div>

      {/* Hazard details panel */}
      <AnimatePresence>
        {selectedHazardData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-4 left-4 right-4 max-w-md bg-[#0B2B5A]/95 backdrop-blur-md rounded-lg p-6 text-[#F7F9FB] shadow-2xl"
          >
            <button
              onClick={() => setSelectedHazard(null)}
              className="absolute top-4 right-4 text-[#F7F9FB]/70 hover:text-[#F7F9FB]"
            >
              ✕
            </button>
            
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg`} style={{ backgroundColor: hazardColors[selectedHazardData.type] }}>
                {(() => {
                  const Icon = hazardIcons[selectedHazardData.type];
                  return <Icon className="w-6 h-6 text-white" />;
                })()}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-lg">{selectedHazardData.title}</h3>
                  <span className={`px-2 py-1 rounded text-xs ${
                    selectedHazardData.severity === 'critical' ? 'bg-[#E94B35]' :
                    selectedHazardData.severity === 'high' ? 'bg-[#FF9A00]' :
                    'bg-[#568203]'
                  }`}>
                    {selectedHazardData.severity.toUpperCase()}
                  </span>
                </div>
                
                <p className="text-sm text-[#F7F9FB]/80 mb-3">{selectedHazardData.description}</p>
                
                <div className="text-xs text-[#F7F9FB]/60 space-y-1">
                  <div>Reported: {new Date(selectedHazardData.reportedAt).toLocaleString()}</div>
                  <div>Source: {selectedHazardData.reportedBy}</div>
                  <div>Affected Radius: {selectedHazardData.affectedRadius}m</div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating action buttons */}
      <div className="absolute bottom-8 right-4 flex flex-col gap-3">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onEvacuate}
          className="p-4 bg-[#E94B35] hover:bg-[#E94B35]/90 text-white rounded-full shadow-lg transition-all duration-300"
        >
          <AlertTriangle className="w-6 h-6" />
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onCreateReport}
          className="p-4 bg-[#568203] hover:bg-[#6a9e04] text-white rounded-full shadow-lg transition-all duration-300"
        >
          <Plus className="w-6 h-6" />
        </motion.button>
      </div>
    </div>
  );
}
