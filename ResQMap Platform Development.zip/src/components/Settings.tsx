import { motion } from 'motion/react';
import { ArrowLeft, Moon, Sun, Wifi, WifiOff, Bell, BellOff, Map, Download, Trash2 } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { useState } from 'react';

/**
 * Settings Screen
 * 
 * Features:
 * - Theme toggle
 * - Offline mode
 * - Notification preferences
 * - Map style selection
 * - Cache management
 * - Accessibility options
 */

interface SettingsProps {
  onBack: () => void;
}

export function Settings({ onBack }: SettingsProps) {
  const { offlineMode, toggleOfflineMode, reducedMotion, toggleReducedMotion, user } = useAppContext();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [mapStyle, setMapStyle] = useState<'dark' | 'light' | 'satellite'>('dark');

  const mapStyles = [
    { id: 'dark', label: 'Dark', preview: '#0B2B5A' },
    { id: 'light', label: 'Light', preview: '#F7F9FB' },
    { id: 'satellite', label: 'Satellite', preview: '#2C5530' }
  ] as const;

  return (
    <div className="w-full h-full bg-gradient-to-b from-[#0B2B5A] to-[#1a3a6e] overflow-y-auto">
      {/* Header */}
      <div className="bg-[#0B2B5A]/80 backdrop-blur-md border-b border-white/10 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-[#F7F9FB] hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Map
          </button>
          <h1 className="text-3xl text-[#F7F9FB]">Settings</h1>
          {user && (
            <p className="text-sm text-[#F7F9FB]/60 mt-2">
              Logged in as {user.name} ({user.role})
            </p>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        {/* Appearance */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6"
        >
          <h2 className="text-xl text-[#F7F9FB] mb-4">Appearance</h2>
          
          <div className="space-y-4">
            {/* Theme toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {darkMode ? <Moon className="w-5 h-5 text-[#F7F9FB]" /> : <Sun className="w-5 h-5 text-[#FF9A00]" />}
                <div>
                  <div className="text-[#F7F9FB]">Dark Mode</div>
                  <div className="text-sm text-[#F7F9FB]/60">Reduce eye strain in low light</div>
                </div>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  darkMode ? 'bg-[#568203]' : 'bg-white/20'
                }`}
              >
                <motion.div
                  animate={{ x: darkMode ? 24 : 0 }}
                  className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full"
                />
              </button>
            </div>

            {/* Reduced motion */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[#F7F9FB]">Reduced Motion</div>
                <div className="text-sm text-[#F7F9FB]/60">Minimize animations</div>
              </div>
              <button
                onClick={toggleReducedMotion}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  reducedMotion ? 'bg-[#568203]' : 'bg-white/20'
                }`}
              >
                <motion.div
                  animate={{ x: reducedMotion ? 24 : 0 }}
                  className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full"
                />
              </button>
            </div>
          </div>
        </motion.section>

        {/* Map Settings */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6"
        >
          <h2 className="text-xl text-[#F7F9FB] mb-4 flex items-center gap-2">
            <Map className="w-5 h-5" />
            Map Settings
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-[#F7F9FB]/70 mb-3">Map Style</label>
              <div className="grid grid-cols-3 gap-3">
                {mapStyles.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => setMapStyle(style.id)}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      mapStyle === style.id
                        ? 'border-[#568203] bg-[#568203]/20'
                        : 'border-white/10 bg-white/5 hover:border-white/20'
                    }`}
                  >
                    <div
                      className="w-full h-16 rounded mb-2"
                      style={{ backgroundColor: style.preview }}
                    />
                    <span className="text-sm text-[#F7F9FB]">{style.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.section>

        {/* Connectivity */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6"
        >
          <h2 className="text-xl text-[#F7F9FB] mb-4">Connectivity</h2>
          
          <div className="space-y-4">
            {/* Offline mode */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {offlineMode ? <WifiOff className="w-5 h-5 text-[#FF9A00]" /> : <Wifi className="w-5 h-5 text-[#568203]" />}
                <div>
                  <div className="text-[#F7F9FB]">Offline Mode</div>
                  <div className="text-sm text-[#F7F9FB]/60">Use cached map data</div>
                </div>
              </div>
              <button
                onClick={toggleOfflineMode}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  offlineMode ? 'bg-[#FF9A00]' : 'bg-[#568203]'
                }`}
              >
                <motion.div
                  animate={{ x: offlineMode ? 24 : 0 }}
                  className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full"
                />
              </button>
            </div>

            {/* Download maps */}
            <button className="w-full flex items-center justify-between p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-3">
                <Download className="w-5 h-5 text-[#568203]" />
                <div className="text-left">
                  <div className="text-[#F7F9FB]">Download Maps</div>
                  <div className="text-sm text-[#F7F9FB]/60">Current region: San Francisco Bay Area</div>
                </div>
              </div>
              <span className="text-sm text-[#568203]">250 MB</span>
            </button>
          </div>
        </motion.section>

        {/* Notifications */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6"
        >
          <h2 className="text-xl text-[#F7F9FB] mb-4">Notifications</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {notifications ? <Bell className="w-5 h-5 text-[#F7F9FB]" /> : <BellOff className="w-5 h-5 text-[#F7F9FB]/40" />}
                <div>
                  <div className="text-[#F7F9FB]">Push Notifications</div>
                  <div className="text-sm text-[#F7F9FB]/60">Critical alerts and updates</div>
                </div>
              </div>
              <button
                onClick={() => setNotifications(!notifications)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  notifications ? 'bg-[#568203]' : 'bg-white/20'
                }`}
              >
                <motion.div
                  animate={{ x: notifications ? 24 : 0 }}
                  className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full"
                />
              </button>
            </div>
          </div>
        </motion.section>

        {/* Data & Cache */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6"
        >
          <h2 className="text-xl text-[#F7F9FB] mb-4">Data & Storage</h2>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
              <div>
                <div className="text-[#F7F9FB]">Cache Size</div>
                <div className="text-sm text-[#F7F9FB]/60">45 MB of cached data</div>
              </div>
              <button className="flex items-center gap-2 px-4 py-2 bg-[#E94B35]/20 text-[#E94B35] rounded hover:bg-[#E94B35]/30 transition-colors">
                <Trash2 className="w-4 h-4" />
                Clear Cache
              </button>
            </div>
          </div>
        </motion.section>

        {/* About */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6"
        >
          <h2 className="text-xl text-[#F7F9FB] mb-4">About</h2>
          <div className="space-y-2 text-sm text-[#F7F9FB]/70">
            <div className="flex justify-between">
              <span>Version</span>
              <span className="text-[#F7F9FB]">1.0.0 (Demo)</span>
            </div>
            <div className="flex justify-between">
              <span>Build</span>
              <span className="text-[#F7F9FB]">2024.11.22</span>
            </div>
            <div className="flex justify-between">
              <span>API Status</span>
              <span className="text-[#568203]">Connected</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-white/10 text-xs text-[#F7F9FB]/50">
            <p>ResQMap - Real-time Disaster Relief Mapping Platform</p>
            <p className="mt-1">Built with React, TypeScript, Mapbox GL JS, and React-Three-Fiber</p>
          </div>
        </motion.section>
      </div>
    </div>
  );
}
