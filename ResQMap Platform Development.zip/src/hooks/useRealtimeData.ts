import { useState, useEffect } from 'react';

/**
 * Mock Realtime Data Hook
 * 
 * Simulates live hazard updates, responder tracking, and crowd density
 * 
 * PRODUCTION INTEGRATION:
 * Replace this with Supabase realtime subscriptions:
 * 
 * const supabase = createClient(url, key)
 * supabase
 *   .channel('hazards')
 *   .on('postgres_changes', { event: '*', schema: 'public', table: 'hazards' }, handleChange)
 *   .subscribe()
 */

export interface Hazard {
  id: string;
  type: 'fire' | 'flood' | 'roadblock' | 'collapse' | 'medical';
  severity: 'low' | 'medium' | 'high' | 'critical';
  location: [number, number]; // [lng, lat]
  title: string;
  description: string;
  reportedAt: string;
  reportedBy: string;
  status: 'active' | 'resolved' | 'investigating';
  affectedRadius: number; // meters
}

export interface Responder {
  id: string;
  name: string;
  type: 'fire' | 'medical' | 'police' | 'rescue';
  location: [number, number];
  status: 'available' | 'enroute' | 'onscene' | 'offduty';
  assignedHazard?: string;
  lastUpdate: string;
}

export interface CrowdDensity {
  location: [number, number];
  count: number;
  timestamp: string;
}

// Mock data for San Francisco Bay Area
const initialHazards: Hazard[] = [
  {
    id: 'h1',
    type: 'fire',
    severity: 'critical',
    location: [-122.4194, 37.7749],
    title: 'Structure Fire - Mission District',
    description: 'Multi-story residential building on fire',
    reportedAt: new Date(Date.now() - 15 * 60000).toISOString(),
    reportedBy: 'SFFD',
    status: 'active',
    affectedRadius: 500
  },
  {
    id: 'h2',
    type: 'flood',
    severity: 'high',
    location: [-122.3988, 37.7911],
    title: 'Flash Flooding - Embarcadero',
    description: 'Water main break causing street flooding',
    reportedAt: new Date(Date.now() - 30 * 60000).toISOString(),
    reportedBy: 'SF Public Works',
    status: 'investigating',
    affectedRadius: 300
  },
  {
    id: 'h3',
    type: 'roadblock',
    severity: 'medium',
    location: [-122.4083, 37.7833],
    title: 'Road Closure - Market St',
    description: 'Vehicle accident blocking 2 lanes',
    reportedAt: new Date(Date.now() - 45 * 60000).toISOString(),
    reportedBy: 'SFPD',
    status: 'active',
    affectedRadius: 150
  },
  {
    id: 'h4',
    type: 'collapse',
    severity: 'critical',
    location: [-122.4324, 37.7599],
    title: 'Building Collapse - Potrero Hill',
    description: 'Partial structural collapse, possible trapped victims',
    reportedAt: new Date(Date.now() - 10 * 60000).toISOString(),
    reportedBy: 'SF Urban Search & Rescue',
    status: 'active',
    affectedRadius: 400
  }
];

const initialResponders: Responder[] = [
  {
    id: 'r1',
    name: 'Engine 1',
    type: 'fire',
    location: [-122.4180, 37.7760],
    status: 'onscene',
    assignedHazard: 'h1',
    lastUpdate: new Date().toISOString()
  },
  {
    id: 'r2',
    name: 'Ambulance 23',
    type: 'medical',
    location: [-122.4200, 37.7740],
    status: 'enroute',
    assignedHazard: 'h1',
    lastUpdate: new Date().toISOString()
  },
  {
    id: 'r3',
    name: 'Rescue Squad 5',
    type: 'rescue',
    location: [-122.4310, 37.7610],
    status: 'onscene',
    assignedHazard: 'h4',
    lastUpdate: new Date().toISOString()
  },
  {
    id: 'r4',
    name: 'Police Unit 12',
    type: 'police',
    location: [-122.4090, 37.7840],
    status: 'onscene',
    assignedHazard: 'h3',
    lastUpdate: new Date().toISOString()
  }
];

export function useRealtimeData() {
  const [hazards, setHazards] = useState<Hazard[]>(initialHazards);
  const [responders, setResponders] = useState<Responder[]>(initialResponders);
  const [crowdDensity, setCrowdDensity] = useState<CrowdDensity[]>([]);

  // Simulate realtime updates every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      // Update responder positions (simulate movement)
      setResponders(prev => prev.map(responder => {
        if (responder.status === 'enroute' && responder.assignedHazard) {
          const hazard = hazards.find(h => h.id === responder.assignedHazard);
          if (hazard) {
            // Move 10% closer to hazard location
            const currentLng = responder.location[0];
            const currentLat = responder.location[1];
            const targetLng = hazard.location[0];
            const targetLat = hazard.location[1];
            
            const newLng = currentLng + (targetLng - currentLng) * 0.1;
            const newLat = currentLat + (targetLat - currentLat) * 0.1;
            
            // If close enough, mark as on scene
            const distance = Math.sqrt(
              Math.pow(targetLng - newLng, 2) + Math.pow(targetLat - newLat, 2)
            );
            
            return {
              ...responder,
              location: [newLng, newLat],
              status: distance < 0.001 ? 'onscene' : 'enroute',
              lastUpdate: new Date().toISOString()
            };
          }
        }
        return responder;
      }));

      // Randomly update crowd density (for heatmap)
      const densityPoints: CrowdDensity[] = [];
      for (let i = 0; i < 20; i++) {
        densityPoints.push({
          location: [
            -122.45 + Math.random() * 0.08,
            37.75 + Math.random() * 0.08
          ],
          count: Math.floor(Math.random() * 100),
          timestamp: new Date().toISOString()
        });
      }
      setCrowdDensity(densityPoints);
    }, 5000);

    return () => clearInterval(interval);
  }, [hazards]);

  // Add new hazard (callable from report creation)
  const addHazard = (hazard: Omit<Hazard, 'id' | 'reportedAt' | 'status'>) => {
    const newHazard: Hazard = {
      ...hazard,
      id: `h${Date.now()}`,
      reportedAt: new Date().toISOString(),
      status: 'active'
    };
    setHazards(prev => [...prev, newHazard]);
  };

  // Update hazard status
  const updateHazardStatus = (id: string, status: Hazard['status']) => {
    setHazards(prev => prev.map(h => h.id === id ? { ...h, status } : h));
  };

  return {
    hazards,
    responders,
    crowdDensity,
    addHazard,
    updateHazardStatus
  };
}
